LIFEDROP - FIREBASE DONOR DATABASE

1. Create a Firebase project.
2. Add a Web App.
3. Copy the firebaseConfig object into LifeDrop_Firebase.html.
4. Create Firestore Database.
5. Apply firestore.rules.
6. The donor form saves records in the "donors" collection.
7. Admin Dashboard -> Registered Donors shows all registrations and supports blood-group/name/phone filtering.

IMPORTANT:
The supplied website uses a front-end demo admin login (admin/admin123). It is retained for your college project. It is NOT production-grade security. For a real public deployment, use Firebase Authentication for the admin login.

ANDROID:
Host the HTML on an HTTPS website (Firebase Hosting/GitHub Pages/etc.) rather than opening it as content:// if your Android browser blocks network requests.
